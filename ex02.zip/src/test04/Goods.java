package test04;

public class Goods 
{
	String name;
	int price;
	int numberOfStock;
	int sold;
}
