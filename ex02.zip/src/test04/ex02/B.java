package test04.ex02;

public class B {

}
