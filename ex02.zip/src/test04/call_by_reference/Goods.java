package test04.call_by_reference;

public class Goods 
{
	int z;
}
