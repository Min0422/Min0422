package ex04;

public class ex01 {

	public static void main(String[] args) {
		TV myTV = new TV("LG", 2017, 32); // LG에서 만든 2017년 65인치
		myTV.show();
	}

}
