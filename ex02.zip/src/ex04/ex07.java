package ex04;

public class ex07 
{
	public static void main(String[] args) {
		MonthSchedule april = new MonthSchedule(30); // 4월달의 할 일
		april.run();
	}

}
