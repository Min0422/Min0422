package ex04;

public class ex08 {

	public static void main(String[] args) {
//		PhoneBook pb1 = new PhoneBook();
//		pb1.run()
		
		new PhoneBook().run();
	}

}
