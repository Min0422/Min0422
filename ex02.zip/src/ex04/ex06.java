package ex04;

public class ex06 {

	public static void main(String[] args) {
	
	}

}
