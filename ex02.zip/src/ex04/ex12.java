package ex04;

public class ex12 {

	public static void main(String[] args) {
	
	}

}
