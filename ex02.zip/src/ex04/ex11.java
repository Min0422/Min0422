package ex04;

public class ex11 
{
	public static void main(String[] args) 
	{
		new Calc().run(); 
	}
}
