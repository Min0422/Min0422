package ex04;

public class ex10 {

	public static void main(String[] args) {
		//내용
		
		new DictionaryManager().run();
	}

}
