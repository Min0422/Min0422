package ex04;

public class ex03 {

	public static void main(String[] args) {
		
		Song song1 = new Song("Dancing Queen", "ABBA", 1978, "스웨덴");
		song1.show();
		
		Song song2 = new Song();
		song2.show();
	}
}
