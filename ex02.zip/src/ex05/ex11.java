package ex05;


public class ex11 {

	public static void main(String[] args) 
	{
		new CalcManager().run(); 
	}

}
