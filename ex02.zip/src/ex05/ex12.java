package ex05;

public class ex12 {

	public static void main(String[] args) 
	{
//		GraphicEditor ge1 = new GraphicEditor();
//		ge1.run();
		
		new GraphicEditor().run();

	}

}
